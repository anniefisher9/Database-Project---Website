<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Adding Courses</title>
</head>
<body>
<?php
        include 'connectdb.php';
?>

<?php
   $courseName = $_POST["courseName"];
   $courseNum = $_POST["courseNum"];
   $courseSuffix = $_POST["courseSuffix"];
   $courseWeight = $_POST["courseWeight"];	

 if(substr($courseNum, 0,2) != "cs" || substr($courseNum, 0,2) != "CS"){
        echo "The course number must begin with cs \n"."<br>";
   }
  else if(mysqli_num_rows($query2 > 0)){
        echo "The course is already in the database \n"."<br>";
   }
else{	
		
   $query = 'INSERT INTO westernCourses (courseName, weight, suffix, courseNum) values ("' . $courseName . '","' . $courseWeight . '" , "' . $courseSuffix . ' " , "' . $courseNum . ' ")';
   
   $query2 = 'SELECT * from westernCourses WHERE courseNum = "' . $courseNum . '" ';
   if (!mysqli_query($connection, $query)) {
      die("Error: insert failed " . mysqli_error($connection));
   }
   if(substr($courseNum, 0,2) != "cs" || substr($courseNum, 0,2) != "CS"){
   	echo "The course number must begin with cs";
   }
   else if(mysqli_num_rows($query2 > 0)){
	echo "The course is already in the database";
   }
   else {
      echo "Course was added!";
   }
}
    $query2 = 'select * from westernCourses';
        $result = mysqli_query($connection, $query2);

        while ($row = mysqli_fetch_assoc($result)){
                echo '<input type ="radio" name = "courseNum" value= $row["courseNum"] ';
                echo $row["courseNum"];
                echo '">' . $row["courseName"] . ", " . $row["courseNum"] . ", ". $row["suffix"] ." , " . $row["weight"] . " </br>";
        }

   mysqli_close($connection);
?>

<p>
<br>
<a href="index.php">Back to Main Menu</a>
</p>
</body>
</html>

