<!DOCTYPE html>
<html>
<head>
<meta charset= "utf-8">
<title> University Courses Databases </title>
</head>
<body>
<?php
	include "connectdb.php";
?>

<h1> Western Courses Database </h1>
<a name="menu"></a>
<h2>Main Menu:</h2>
<ul>
<form action="getcourses.php" method="get">
            <table width="280" height="25" >

                <tr><td width="61"><p>Sort by:</p></td>
                <td width="72" height="24"><p>Sort Courses by Number Ascending</p></td>
                <td width="28"><input name="sort" type="radio" value="Course Number Ascending" /></td>

                <td width="75" height="24"><p>Sort Courses by Number Descending</p></td>
                <td width="20"><input name="sort" type="radio" value="Course Number Descending" /></td>
		<td width="72" height="24"><p>Sort Courses by Name Ascending</p></td>
                <td width="28"><input name="sort" type="radio" value="Course Name Ascending" /></td>

                <td width="75" height="24"><p>Sort Courses by Name Descending</p></td>
                <td width="20"><input name="sort" type="radio" value="Course Name Descending" /></td>

            </tr></table>
            
	<input name="searchform1" type="submit" value="Search" class="moreinfobutton" />
</form>   
<br>

<a name="modify_course"></a>
<h1> Modify Course </h1>

<form action="modifycourse.php" method="post"
enctype="multipart/form-data">
Course Number to change: <input type="text" name="courseNum"><br>
Modify course values:<br>
Course Name: <input type="text" name="courseName"><br>
Suffix: <input type="text" name="suffix"><br>
Weight: <input type="test" name="weight"><br>
<input type="submit" value= "Modify Course"><br>

</form>

<a name="add_course"></a>
<h1> Add a New Western Course </h1>

<form action="addnewcourse.php" method="post"
enctype="multipart/form-data">
Add course values:<br>
Course Number: <input type="text" name="courseNum"><br>
Course Name: <input type="text" name="courseName"><br>
Suffix: <input type="text" name="courseSuffix"><br>
Weight: <input type="test" name="courseWeight"><br>
<input type="submit" value= "Add Course"><br>

</form>

</br>
</body>
</html>
