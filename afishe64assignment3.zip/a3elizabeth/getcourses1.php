nclude ("db.connect.php");

                $pages_query = mysql_query("SELECT COUNT('id') FROM `holidaytable` WHERE brandname = 'Cyprus'");
                $count = mysql_result($pages_query, 0);


                echo '<p>There are '.$count.' holidays<hr></p>';                    
                //construct query and insert values

                $sql = "SELECT * FROM holidaytable WHERE brandname = 'Cyprus'";


                if (isset($_GET['priceorderasc'])) $sql .= " ORDER BY buynow ASC";
                if (isset($_GET['priceorderdesc'])) $sql .= " ORDER BY buynow DESC";


                $query = mysql_query($sql) or die(mysql_error());

            include("dbresults.php");

        ?>
