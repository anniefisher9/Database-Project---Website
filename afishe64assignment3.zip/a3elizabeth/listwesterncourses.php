<!DOCTYPE html>
<html>
<head>
<meta charset = "utf-8">
<title> Western Courses </title>
</head>
<body>

<?php
	include 'connetdb.php';
?>

<h1> Courses at Western </h1>

<form action = "westerncourses.php" method="post"
enctype = "multipart/form-data">
<br>
<?php
	include "getcourses.php';
?>

<input type="submit" value = "Find Course">
</form>
<?php>
mysqli_close($connection);
?>

</body>
</html>
